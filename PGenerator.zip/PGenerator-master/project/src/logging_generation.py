import logging

# Parameters of the generation of the log lines :
logging.basicConfig(filename='PGenerator_log.log',level=logging.DEBUG,\
        format='%(asctime)s -- %(levelname)s -- %(message)s')

