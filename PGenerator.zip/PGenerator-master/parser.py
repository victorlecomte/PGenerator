
import argparse
parser = argparse.ArgumentParser()

parser.add_argument("-t", "--title", action = "store", nargs= 2, type= str, help="Song title to search for", metavar=('string','int'))

parser.add_argument("-A", "--album",action = "store", nargs= 2, type= str, help ="Song album to serach for", metavar=('STRING', 'QTY'))

parser.add_argument("-a", "--artist", action = 'store', nargs= 2, type= str, help="Song artist to search for", metavar=('STRING','QTY'))

parser.add_argument("-g", "--genre", action = 'store', nargs = 2, type = str, help="Song genre to search for", metavar=('STRING', 'QTY'))

parser.add_argument("-S", "--sub-gender", action = 'store', nargs = 2, type = str, help="Song sub-gender to search for", metavar=('STRING','QTY'))

parser.add_argument('-d', '--duration',action = 'store', nargs= 2, type= str, help ='Duration of the playlist', metavar=('STRING', 'QTY'))

parser.add_argument("-s", "--size", action = "store", nargs = 2, type = str, help="Song size to serach for", metavar=('STRING', 'QTY'))

parser.add_argument("-p", "--polyphony", action = 'store', nargs = 2,type = str, help="Song polyphony to search for", metavar=('STRING', 'QTY'))
args = parser.parse_args()


