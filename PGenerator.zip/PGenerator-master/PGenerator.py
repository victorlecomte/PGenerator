"""

Created on Tue Sep 11 16:41:12

@author: Hugo MARQUET

"""

# Librairies import

import psycopg2
import argparse
import random
import logging

# Database connection

connect_str = "dbname='h.marquet' user='h.marquet' host='postgresql.bts-malraux72.net'"

# Trying connection to database

try:
    connection = psycopg2.connect(connect_str)
except Exception as error:
    logging.critical('Unable to connect to database')
    exit(1)


# Creating a cursor to execute PostgreSQL command in a database session

cursor = connection.cursor()

# Managing the playlist generator arguments

arguments = argparse.ArgumentParser(description='Playlist Generator')

# Creating arguments for the CLI

arguments.add_argument("-d", "--duration", type=int, help="Playlist duration", required=True)
arguments.add_argument("-g", "--genre", help="Which kind of music", action="store")
arguments.add_argument("-a", "--artiste", help="Artist", action="store")
arguments.add_argument("-t", "--titre", help="title of a music", action="store")

# Allows to manipulate the parsed arguments

args = arguments.parse_args()

# Creating tables to store the result of the query

songsLength = 0 # Data used to compare the sum of the chosen songs with the wanted playlist
countLines = 0 # Counting variable to browse the database's lines
returnedList = [] # List of found songs
timeList = [] # Table to stock the sums of the chosen songs in returnedList[]

# Converting minutes to seconds to compare the sum of the wanted playlist to songs length

wishedLength = args.duration * 60

# Loop

stock = []

for variantParameter in ['genre', 'artiste', 'titre']:
    if hasattr(args, variantParameter) and getattr(args, variantParameter) is not None:
        try:
            cursor.execute('SELECT * FROM "PGenerator".morceaux WHERE ' + variantParameter + " = '" + getattr(args, variantParameter) + "' " + ';')
            stock = cursor.fetchall()
            print(stock)
        except Exception as error:
            logging.critical('this request is not available')
            exit(1)

# Randomizing list

random.shuffle(stock)

# Storing songs title and songs length into lists 

while songsLength < wishedLength:
    songsLength += stock[countLines][5]
    returnedList.append(stock[countLines][0])
    timeList.append(stock[countLines][5])
    countLines += 1
     
# Condition to delete the last song in the list 'returnedList[]' to create margin
    
    if songsLength > wishedLength:
        del returnedList[-1]
        del timeList[-1]

# Displaying lists

print(returnedList, " \t", "\nPlaylist's length : ", sum(timeList), " seconds of ", wishedLength)


"""
------------------------------------------------------------------------
""" 