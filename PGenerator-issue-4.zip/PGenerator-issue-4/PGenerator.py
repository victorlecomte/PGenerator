"""

Created on Tue Sep 11 16:41:12

@author: Hugo MARQUET

"""

# Librairies import

import psycopg2
import argparse
import random
import logging

# Database connection

connect_str = "dbname='h.marquet' user='h.marquet' host='postgresql.bts-malraux72.net'"

# Trying connection to database

try:
    connection = psycopg2.connect(connect_str)
except Exception as error:
    logging.critical('Unable to connect to database')
    exit(1)


# Creating a cursor to execute PostgreSQL command in a database session

cursor = connection.cursor()

# Testing cursor in database

try:
    cursor.execute('SELECT * FROM "PGenerator".morceaux;')
except Exception as error:
    logging.critical('Query not found')
    exit(1)
    
# Storing query in a variable

myRows = cursor.fetchall()

# Randomizating tracks in the CLI

random.shuffle(myRows)
    
# Managing the playlist generator arguments

arguments = argparse.ArgumentParser(description='Playlist Generator')

# Creating arguments for the CLI

arguments.add_argument("-d", "--duration", type=int, help="Playlist duration", required=True)
arguments.add_argument("-g", "--genre", help="Which kind of music", action="store")
arguments.add_argument("-a", "--artist", help="Artist", action="store")
arguments.add_argument("-t", "--title", help="title of a music", action="store")

# Allows to manipulate the parsed arguments

args = arguments.parse_args()

# Converting minutes to seconds to compare the sum of the wanted playlist to songs length

wishedLength = args.duration * 60

# Displaying database's rows 

songsLength = 0 # Data used to compare the sum of the chosen songs with the wanted playlist
countLines = 0 # Counting variable to browse the database's lines
returnedList = [] # List of found songs
timeList = [] # Table to stock the sums of the chosen songs in returnedList[]

# Storing songs title and songs length into lists 

while songsLength < wishedLength:
    songsLength += myRows[countLines][5]
    returnedList.append(myRows[countLines][0])
    timeList.append(myRows[countLines][5])
    countLines += 1
     
# Condition to delete the last song in the list 'returnedList[]' to create margin
    
    if songsLength > wishedLength:
        del returnedList[-1]
        del timeList[-1]

# Displaying lists

#print(returnedList, " \t", "\nPlaylist's length : ", sum(timeList), " seconds of ", wishedLength)

"""
------------------------------------------------------------------------
"""

# Creating tables to store the result of the query
aParameter = []  # Ensemble des éléments issus d'une sélection dans la base pour un paramètre donné
parametersList = []  # Ensemble des paramètres et de leur contenu

for variantParameter in ['genre', 'artiste', 'titre']:
    if hasattr(args, variantParameter) and getattr(args, variantParameter) is not None:
        try:
            cursor.execute('SELECT * FROM "PGenerator".morceaux WHERE ' + variantParameter + " = " + getattr(args, variantParameter) + ';')
            affich = cursor.fetchall()
            print(affich)
        except Exception as error:
            logging.critical('Impossible')
            exit(1)