#Libraires import
import psycopg2
import random
import argparse
import logging

# Try the connection of data base
try:
    connection_db = psycopg2.connect("dbname='v.lecomte' user='v.lecomte' host='postgresql.bts-malraux72.net'")
    print('You are connected at your database, we can continue to use the random playlist program')
except:
    logging.critical('Connection has failed, verify your password')

#Creating a cursor to execute PostgreSQL comand in database
cursor = connection_db.cursor()

# Try the cursor in database
#try:
#   cursor.execute('SELECT * FROM "Generateur_de_playlist".morceaux;')
#except:
#    print ("Query not found")

#rows = cursor.fetchall()

#random.shuffle(rows)

#print ("\nSong in Database\n")
#for row in rows:
#    print("   ", row[0])


#Importation of file "parser.py" in this file for the generation of random playlist
parser = argparse.ArgumentParser()
parser.add_argument("-t", "--title", action = "append", nargs= 2, type=str,  help="Song title to search for", metavar=('STRING','INT'))
parser.add_argument("-A", "--album",action =  "append", nargs= 2, type= str, help ="Song album to serach for", metavar=('STRING', 'INT'))
parser.add_argument("-a", "--artist", action ='append', nargs= 2, type= str, help="Song artist to search for", metavar=('STRING','INT'))
parser.add_argument("-g", "--genre", action = 'append', nargs = 2, type = str, help="Song genre to search for", metavar=('STRING', 'INT'))
parser.add_argument("-S", "--sub-gender", action ='append', nargs =2, type = str, help="Song sub-gender to search for",
 metavar=('STRING', 'INT'))
parser.add_argument('-d', '--duration',action = 'store', type=int, help ='Duration of the playlist',
 metavar=('INT'), required = True)
parser.add_argument("-s", "--size", action ="append", nargs = 2, type = str, help="Song size to serach for", metavar=('STRING', 'INT'))
parser.add_argument("-p", "--polyphony", action = 'append', nargs = 2,type = str, help="Song polyphony to search for",
 metavar=('STRING', 'INT'))

# Exécution de l'analayse de la CLI et récupération des données dans args
args = parser.parse_args()

print(args)

cursor.execute('SELECT * FROM "Generateur_de_playlist".morceaux WHERE genre = \'Hip-Hop\' ORDER BY random();')

rows = cursor.fetchall()


#print("\nDisplay genre Hip-Hop")
#for row in rows:
#    print(" ",row[0], row[3])


#print("\n Display titles:")
#for title in args.title:
#    print(title)

#print("\nDisplay albums :")
#for album in args.album:
#    print(album[0])

#print("\nDisplay artists :")
#for artist in args.artist:
#    print(artist[0])

#print("\nDisplay genres")
#for genre in args.genre:
#    print(genre[0])


#print("\nDisplay size")
#for size in args.size:
#    print(size[0])

#print("\nDisplay poluphony")
#for polyphony in args.polyphony:
#    print(polyphony[0])

# Converting minutes to seconds to compare the sum of the wanted playlist to songs length

wishedLength = args.duration * 60

songsLength = 0 # Data used to compare the sum of the chosen songs with the wanted playlist
countLines = 0 # Counting variable to browse the database's lines
returnedList = [] # List of the found songs
timeList = [] # Table to stock the sums of the chosen songs in returnedList[]

# Source code of Hugo MARQUET (because I understand this code)

print ("\nRandom Songs for a duration enter by the user\n")
while songsLength <= wishedLength:
    songsLength += rows[countLines][5]
    returnedList.append(rows[countLines][0])
    timeList.append(rows[countLines][5])
    countLines += 1

# Condition to delete the last song in the list 'returnedList[]' to create margin
    if songsLength > wishedLength:
        del returnedList[-1]
        del timeList[-1]

# Displaying lists

print(returnedList, " \t", "\nPlaylist's length : ", sum(timeList), " seconds of ", wishedLength)
