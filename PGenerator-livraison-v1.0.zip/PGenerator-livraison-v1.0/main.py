"""

Created on Tue Sep 11 16:41:12

@author: Hugo MARQUET

"""

# Librairies import

import psycopg2
import argparse
import random
import logging
import os

# Database connection

connect_str = "dbname='h.marquet' user='h.marquet' host='postgresql.bts-malraux72.net' password='P@ssword'"

# Trying connection to database

try:
    connection = psycopg2.connect(connect_str)
except Exception as error:
    logging.critical('Unable to reach to database')
    exit(1)


# Creating a cursor to execute PostgreSQL command in a database session

cursor = connection.cursor()

# Managing the playlist generator arguments

arguments = argparse.ArgumentParser(description='Playlist Generator')

# Creating arguments for the CLI

arguments.add_argument("-d", "--duration", type=int, help="Playlist duration", required=True)
arguments.add_argument("-g", "--genre", help="Which kind of music", action="store")
arguments.add_argument("-a", "--artiste", help="Artist", action="store")
arguments.add_argument("-t", "--titre", help="title of a music", action="store")

# Allows to manipulate the parsed arguments

args = arguments.parse_args()

# Creating tables to store the result of the query

songsLength = 0 # Data used to compare the sum of the chosen songs with the wanted playlist
countLines = 0 # Counting variable to browse the database's lines
returnedList = [] # List of found songs
timeList = [] # Table to stock the sums of the chosen songs in returnedList[]

# Converting minutes to seconds to compare the sum of the wanted playlist to songs length

wishedLength = args.duration * 60

# Deleting an existing old m3u file and creating a new one to receive the playlist

os.remove('playlist.m3u')
exportm3u = open("playlist.m3u", "a")

# Loop
for variantParameter in ['genre', 'artiste', 'titre']:
    if hasattr(args, variantParameter) and getattr(args, variantParameter) is not None:
        cursor.execute('SELECT titre, album, artiste, genre, duree, chemin FROM "PGenerator".morceaux WHERE ' + variantParameter + " = '" + getattr(args, variantParameter) + "' " + ';')
        enregistrements = cursor.fetchall()
        for enregistrement in enregistrements:
            titre, album, artiste, genre, duree, chemin = enregistrement
            returnedList.append(enregistrement)
            songsLength += duree
            print(duree, chemin)
            exportm3u.write("\n" + chemin) # writing in the m3u file the wanted song every iteration of the loop
        print(songsLength)

exportm3u.close()

#    print(songsLength)
    
#            while songsLength < wishedLength:
#               if (duree + songsLength) < wishedLength:
#                    returnedList.append(enregistrement)
#                    songsLength += duree
#                    print(duree, chemin)
#            print(songsLength)"""

# Randomizing list

"""random.shuffle(stock)"""

# Storing songs title and songs length into lists 
"""
while songsLength < wishedLength:
    songsLength += stock[countLines][5]
    returnedList.append(stock[countLines][0])
    timeList.append(stock[countLines][5])
    countLines += 1
     
# Condition to delete the last song in the list 'returnedList[]' to create margin
    
    if songsLength > wishedLength:
        del returnedList[-1]
        del timeList[-1]

# Displaying lists

print(returnedList, " \t", "\nPlaylist's length : ", sum(timeList), " seconds of ", wishedLength)

"""
"""
------------------------------------------------------------------------
""" 