Ceci est le début du projet collaboratif consistant en l'élaboration d'un générateur de playlist pour la webradio du lycée André Malraux.
De Hugo MARQUET et Victor LECOMTE.

Si vous souhaitez, vous pouvez tirer les documents voulus du dépot (programme ou bien documentation)
